---
title: useSize
nav:
  title: Hooks
  path: /hooks
group:
  title: all
  path: /usesize
---

# useSize

警告提示，展现需要关注的信息。

## 代码演示

### 基本用法

<code src="./demo/basic.tsx"></code>