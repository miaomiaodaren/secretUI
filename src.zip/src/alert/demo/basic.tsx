import React from 'react';
import Alert from '../';
import '../style';

export default () => <Alert text="warning"></Alert>;